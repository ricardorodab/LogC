{-Facultad de Ciencias UNAM - Lógica Computacional 2015-2 
		  Profesor: Dr. Favio Ezequiel Miranda 
		  Ayudante: José Manuel Reyes Snyder
		  Laboratorio: C. Moisés Vázquez Reyes-}

--Para términos
type Nombre = String
data Term = V Nombre | F Nombre [Term] deriving (Show, Eq)

--Lógica de primer orden
data Form = TrueF |           -- ⊤
			FalseF|           -- ⊥
			Pr Nombre [Term]| -- P(t1,t2,⋯,tn) 
			Eq Term Term | 	  -- t1 = t2
			Neg Form |        -- ¬ φ
			Conj Form Form |  -- φ ⋀ ψ
			Disy Form Form |  -- φ ⋁ ψ
			Imp Form Form |   -- φ → ψ
			Equi Form Form |  -- φ ↔ ψ
			All Nombre Form | -- ∀x φ
			Ex Nombre Form 	 {-- ∃x φ  --} deriving (Show, Eq) 

--Estados de variables en el universo 'a'
type Estado a = Nombre -> a

--Interpretación para símbolos de función
type IntF a = Nombre -> [a] -> a

--Interpretación para símbolos de relación
type IntR a = Nombre -> [a] -> Bool


--Actualización un estado en una variable 
actEst :: Estado a -> Nombre -> a -> Estado a
actEst f x m = \y -> if y == x then m else f y


--Interpretación de términos
iTerm :: Estado a -> IntF a -> Term -> a
iTerm g h t = error "te toca"


--Interpretación de fórmulas
iForm :: Eq a => [a] -> Estado a -> IntF a -> IntR a -> Form -> Bool
iForm = error "te toca"



--Una figura es un círculo, un triángulo o un cuadrado.
data Fig = Circ | Trian | Cuadr deriving (Show, Eq)
--Hay tres tamaños: pequeño, mediano, grande.
data Tam = Peq | Med | Gran deriving (Show, Eq)
--Las primeras dos coordenadas son la posición en el plano de las 
--figuras, la tercera el tipo de figura y la cuarta su tamaño.
type Figura = (Int, Int, Fig, Tam) 


est :: Estado Figura
est = \_ -> (0,0,Circ,Peq)

iF :: IntF Figura
iF = \_ -> \_ -> (0,0,Circ,Peq) 

--Interpretación de predicados
iR :: IntR Figura
iR = error "te toca"

--La lista de figuras en el plano.
mundoFiguras :: [Figura]
mundoFiguras = error "te toca"

--[False]
--Ningún cuadrado está al norte de un círculo grande.
prueba1 = iForm mundoFiguras est iF iR $ Neg $ Ex "x" $ Conj (Pr "Q" [V "x"])
			 (Ex "y" $ Conj (Conj (Pr "C" [V "y"]) (Pr "G" [V "y"])) (Pr "N" [V "x", V "y"])) 

--[True]
--Todos los círculos medianos están al oeste de un mismo triángulo grande.
prueba2 = error "te toca" 

--[False]
--Todos los cuadrados pequeños están al sur de cualquier triángulo.
prueba3 = error "te toca"

--[False]
--Si dos cuadrados están en el mismo renglón, entonces cualquier triángulo al sur de ambos es mediano.
prueba4 = error "te toca"
