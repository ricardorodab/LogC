{-Facultad de Ciencias UNAM - Lógica Computacional 2015-2 
		  Profesor: Dr. Favio Ezequiel Miranda 
		  Ayudante: José Manuel Reyes Snyder
		  Laboratorio: C. Moisés Vázquez Reyes-}

--Para términos
type Nombre = String
data Term = V Nombre | F Nombre [Term] deriving (Show, Eq)

--Lógica de primer orden
data Form = TrueF |           -- ⊤
			FalseF|           -- ⊥
			Pr Nombre [Term]| -- P(t1,t2,⋯,tn) 
			Eq Term Term | 	  -- t1 = t2
			Neg Form |        -- ¬ φ
			Conj Form Form |  -- φ ⋀ ψ
			Disy Form Form |  -- φ ⋁ ψ
			Imp Form Form |   -- φ → ψ
			Equi Form Form |  -- φ ↔ ψ
			All Nombre Form | -- ∀x φ
			Ex Nombre Form 	 {-- ∃x φ  --} deriving (Show, Eq) 

--Estados de variables en el universo 'a'
type Estado a = Nombre -> a

--Interpretación para símbolos de función
type IntF a = Nombre -> [a] -> a

--Interpretación para símbolos de relación
type IntR a = Nombre -> [a] -> Bool


--Actualización un estado en una variable 
actEst :: Estado a -> Nombre -> a -> Estado a
actEst = error "Te toca"


--Interpretación de términos
iTerm :: Estado a -> IntF a -> Term -> a
iTerm = error "Te toca"

--Interpretación de fórmulas
iForm :: Eq a => [a] -> Estado a -> IntF a -> IntR a -> Form -> Bool
iForm = error "Te toca"

--Universo
m :: [Int]
m = error "Te toca"

--Estado de variables
est :: Estado Int 
est = error "Te toca"

--Interpretación de fórmulas
iF :: IntF Int
iF = error "Te toca"

--Interpretación de predicados
iR :: IntR Int
iR = error "Te toca"

--PRUEBAS:

-- [False]
-- ∀x∊m(∃y∊m(x + y = 0)	
prueba1 = iForm m est iF iR $ All "x" $ Ex "y" $ Pr "C" [F "f" [V "x", V "y"]]

-- [True]
-- x+x = z-x	[x ↦ 2, z ↦ 6]
prueba2 = error "Te toca"

-- [True]
-- ∀x ∊ m(∀y ∊ m(x+y = 0 → x = 0 ⋀ y = 0))
prueba3 = error "Te toca"

-- [True]
-- (x < y) ⋀ (z + w = y)	[x ↦ 2, y ↦ 10, z ↦ 6, w ↦ 4]
prueba4 = error "Te toca"

-- [True]
-- ∀x∊m(∃y∊m(x - y = 0)	
prueba5 = error "Te toca"


