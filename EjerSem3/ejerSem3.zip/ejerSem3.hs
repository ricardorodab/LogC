{-Facultad de Ciencias UNAM - Lógica Computacional 2014-2 
		  Profesor: Dr. Favio Ezequiel Miranda 
		  Ayudante: José Manuel Reyes Snyder
		  Laboratorio: C. Moisés Vázquez Reyes-}

--Para términos
type Nombre = String
data Term = V Nombre | F Nombre [Term] deriving (Show, Eq)

--Funciones que asignan un estado a cada variable.
type Estado = Nombre -> Int

--Interpretación para símbolos de función.
type IntF = Nombre -> [Int] -> Int



--Interpretación de términos
interp :: Estado -> IntF -> Term -> Int
--Aquí te toca.		
	

est1 :: Estado 
--Aquí te toca.

iF1 :: IntF 
--Aquí te toca.


--Pruebas:
--Debe de dar 21
prueba1 = interp est1 iF1 (F "h" [F "a" [], V "y"]) 
--Debe de dar 588
prueba2 = interp est1 iF1 (F "f" [V "x", V "x", V "y"]) 
--Debe de dar 6209
prueba3 = interp est1 iF1 (F "g" [V "x", V "y", F "h" [V "y", F "h" [V "y", V "x"]]]) 
-- Debe de dar 0
prueba4 = interp est1 iF1 (F "h" [ F "f" [V "a", V "b", V "c"], V "x"]) 
--Debe dar 210
prueba5 = interp est1 iF1 (F "h" [V "y", F "g" [F "m" [], F "o" [], V "z"]]) 


